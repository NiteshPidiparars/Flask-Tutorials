# My-Python-Flask-Blog
This is a [flask](https://flask.palletsprojects.com/en/1.1.x/) based blog whose frontend is created using bootstrap.
If you have any questions or suggestions, feel free to open an issue or pull request :)
